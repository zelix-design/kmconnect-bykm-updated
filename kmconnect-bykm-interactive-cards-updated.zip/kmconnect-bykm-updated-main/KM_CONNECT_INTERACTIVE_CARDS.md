# KM Connect interactive dashboard tiles

Implemented in the existing overview dashboard without adding dependencies.

## Changes
- `frontend/src/pages/Dashboard.jsx`: added pointer handlers to existing overview tiles. Existing click behavior, data state, role filtering, and routes remain unchanged.
- `frontend/src/index.css`: added restrained 3D tilt, cursor-following red glow, staggered entrance, focus styling, touch fallback, and reduced-motion support.

## Behavior
- Tilt is limited to a few degrees and driven by CSS custom properties rather than React state.
- Glow follows mouse/pen pointer position.
- Touch/coarse-pointer and reduced-motion modes disable pointer-following motion.
- Existing tile filtering by role and `data-testid` selectors are preserved.
- No new dependencies or API changes.

## Validation
This source patch was made against the uploaded project. Run the project's normal frontend checks from `frontend/` (for example `yarn build` and the relevant tests) before deployment.
