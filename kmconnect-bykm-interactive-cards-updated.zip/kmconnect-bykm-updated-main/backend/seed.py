"""Default category catalogue + seeding / backfill helpers."""
import os

from db import db
from auth_lib import hash_password, gen_id, now_iso


DEFAULT_CATEGORIES = [
    {"name": "Sales", "type": "income", "color": "#059669", "icon": "TrendUp"},
    {"name": "Services", "type": "income", "color": "#10b981", "icon": "Briefcase"},
    {"name": "Other Income", "type": "income", "color": "#34d399", "icon": "Coins"},
    {"name": "Application Fees", "type": "income", "color": "#14b8a6", "icon": "FileText"},
    {"name": "Registration Fees", "type": "income", "color": "#0d9488", "icon": "ClipboardText"},
    {"name": "Admission Fees", "type": "income", "color": "#0d9488", "icon": "GraduationCap"},
    {"name": "Booking Amount", "type": "income", "color": "#0891b2", "icon": "BookmarkSimple"},
    {"name": "Fees (part payment)", "type": "income", "color": "#0284c7", "icon": "Coin"},
    {"name": "Tuition Fees", "type": "income", "color": "#2563eb", "icon": "BookOpen"},
    {"name": "Tution Fees", "type": "income", "color": "#2563eb", "icon": "BookOpen"},
    {"name": "Uniform Fees", "type": "income", "color": "#6366f1", "icon": "TShirt"},
    {"name": "Sem Fees", "type": "income", "color": "#4f46e5", "icon": "Books"},
    {"name": "Yearly Fees", "type": "income", "color": "#7c3aed", "icon": "Calendar"},
    {"name": "Other Fees", "type": "income", "color": "#0f766e", "icon": "Receipt"},
    {"name": "SC Adjusted", "type": "income", "color": "#a855f7", "icon": "ArrowsLeftRight"},
    {"name": "Rent", "type": "expense", "color": "#be123c", "icon": "House"},
    {"name": "Fuel Exp", "type": "expense", "color": "#b91c1c", "icon": "GasPump"},
    {"name": "Toll", "type": "expense", "color": "#c2410c", "icon": "Road"},
    {"name": "Cab Exp", "type": "expense", "color": "#a16207", "icon": "Car"},
    {"name": "Train/Bus Booking", "type": "expense", "color": "#7c2d12", "icon": "Train"},
    {"name": "Food", "type": "expense", "color": "#dc2626", "icon": "ForkKnife"},
    {"name": "Utilities", "type": "expense", "color": "#9f1239", "icon": "Lightning"},
    {"name": "Salaries", "type": "expense", "color": "#525252", "icon": "Users"},
    {"name": "Office Supplies", "type": "expense", "color": "#92400e", "icon": "Package"},
    {"name": "Marketing", "type": "expense", "color": "#7c2d12", "icon": "Megaphone"},
    {"name": "Travel", "type": "expense", "color": "#0e7490", "icon": "Airplane"},
    {"name": "Software", "type": "expense", "color": "#4338ca", "icon": "Cpu"},
    {"name": "Other", "type": "expense", "color": "#78716c", "icon": "DotsThree"},
]


async def seed_user_defaults(user_id: str) -> None:
    cats = [
        {"id": gen_id(), "user_id": user_id, "created_at": now_iso(), **c}
        for c in DEFAULT_CATEGORIES
    ]
    await db.categories.insert_many(cats)
    await db.accounts.insert_one({
        "id": gen_id(),
        "user_id": user_id,
        "name": "Main Bank",
        "type": "bank",
        "opening_balance": 0.0,
        "color": "#10b981",
        "created_at": now_iso(),
    })


async def seed_admin_and_backfill() -> None:
    """Idempotent: ensures admin user exists, password is fresh, and every user
    has the full default category set.

    Migration: if ``ADMIN_EMAIL`` has changed (e.g. moving from a placeholder
    domain to a real one) and no user yet matches the new email, but the
    legacy ``admin@finflow.com`` row exists as super_admin, we *migrate* that
    row's email + password instead of creating a duplicate super admin.
    """
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@finflow.com").lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "Admin@123")
    existing = await db.users.find_one({"email": admin_email})

    # One-time migration of the seeded admin email/password (idempotent: only
    # runs when the new email isn't claimed yet AND a legacy super_admin row
    # exists that we can safely rename). We try each legacy email in order
    # and rename the first match — preserving the ``user_id`` so all linked
    # data (students / invoices / accounts / referrer_user_id on leads and
    # students) keeps pointing at the same row after the rename.
    LEGACY_ADMIN_EMAILS = ["admin@finflow.com", "admin@kmfoundation.online"]
    if existing is None and admin_email not in LEGACY_ADMIN_EMAILS:
        for legacy_email in LEGACY_ADMIN_EMAILS:
            legacy = await db.users.find_one({"email": legacy_email})
            if legacy and legacy.get("role") == "super_admin":
                await db.users.update_one(
                    {"id": legacy["id"]},
                    {"$set": {
                        "email": admin_email,
                        "password_hash": hash_password(admin_password),
                        "approval_status": "approved",
                        "role": "super_admin",
                    }},
                )
                existing = await db.users.find_one({"email": admin_email})
                break

    if existing is None:
        user_id = gen_id()
        await db.users.insert_one({
            "id": user_id,
            "email": admin_email,
            "name": "Super Admin",
            "business_name": "FinFlow by KM Foundation",
            "password_hash": hash_password(admin_password),
            "currency": "INR",
            "role": "super_admin",
            "office": None,
            "approval_status": "approved",
            "created_at": now_iso(),
        })
        await seed_user_defaults(user_id)
    else:
        # Ensure role / approval_status are correct (idempotent backfill).
        # SEC-004: do NOT overwrite the password on restart. If an admin
        # has rotated their password via the UI/API, resetting it back to
        # the seed value on every boot would silently undo that rotation
        # (and any manual rotation would be reverted the next time the
        # pod restarts). We only set the password on first seed (the
        # ``insert_one`` branch above) — genuine rotations must survive.
        patch = {}
        if existing.get("role") != "super_admin":
            patch["role"] = "super_admin"
        if existing.get("approval_status") != "approved":
            patch["approval_status"] = "approved"
        if patch:
            await db.users.update_one({"email": admin_email}, {"$set": patch})

    # Backfill role for *legacy* users that have an unknown/missing role so
    # they can still log in. IMPORTANT: never touch valid roles — converting
    # "user" (sub-agents) or "staff" (CRM) here would silently destroy those
    # accounts on every restart.
    await db.users.update_many(
        {"role": {"$nin": ["super_admin", "office_admin", "user", "staff"]}},
        {"$set": {"role": "office_admin"}},
    )
    await db.users.update_many(
        {"approval_status": {"$exists": False}},
        {"$set": {"approval_status": "approved"}},  # existing users remain logged in
    )

    # One-time migration: rename lead status "contacted" → "not_connected".
    # The frontend + backend now use `not_connected` for the second pipeline
    # stage. Old data survives if a fresh install imports a legacy dump.
    try:
        await db.leads.update_many(
            {"status": "contacted"}, {"$set": {"status": "not_connected"}}
        )
    except Exception:
        pass

    # One-time migration: rename campus-visit statuses to the extended
    # 9-stage vocabulary (Scheduled → Assigned → Picked Up → Ongoing →
    # Confused → Admission Taken → Fees Paid → Admission Letter Taken → Lost).
    try:
        await db.leads.update_many(
            {"visit.status": "admitted"}, {"$set": {"visit.status": "admission_taken"}}
        )
        await db.leads.update_many(
            {"visit.status": "completed"}, {"$set": {"visit.status": "admission_letter_taken"}}
        )
    except Exception:
        pass

    # Backfill: denormalize `referrer_name` on students that carry a
    # ``referrer_user_id`` but no name yet. Also auto-map the manual
    # `reference` name → referrer_user_id when the reference matches a
    # staff/office_admin/super_admin (so legacy admin-added students
    # surface on that employee's dashboard).
    # Runs on every boot but only touches rows that still need the fix.
    try:
        # Case 1: has referrer_user_id, missing referrer_name.
        pending = await db.students.find(
            {"referrer_user_id": {"$ne": None}, "referrer_name": {"$in": [None, ""]}},
            {"_id": 0, "id": 1, "referrer_user_id": 1},
        ).to_list(5000)
        if pending:
            ref_ids = list({p["referrer_user_id"] for p in pending})
            users = await db.users.find(
                {"id": {"$in": ref_ids}}, {"_id": 0, "id": 1, "name": 1}
            ).to_list(500)
            umap = {u["id"]: u.get("name") for u in users if u.get("name")}
            for p in pending:
                name = umap.get(p["referrer_user_id"])
                if name:
                    await db.students.update_one(
                        {"id": p["id"]}, {"$set": {"referrer_name": name}}
                    )

        # Case 2: has a `reference` name but NO referrer_user_id — try to
        # resolve the name to a login user (case-insensitive, exact match).
        orphaned = await db.students.find(
            {
                "referrer_user_id": {"$in": [None, ""]},
                "reference": {"$nin": [None, ""]},
            },
            {"_id": 0, "id": 1, "reference": 1},
        ).to_list(5000)
        if orphaned:
            # Build a case-insensitive lookup once for all staff/admin names.
            users = await db.users.find(
                {"role": {"$in": ["staff", "office_admin", "super_admin"]}, "name": {"$ne": None}},
                {"_id": 0, "id": 1, "name": 1},
            ).to_list(2000)
            by_lower = {}
            for u in users:
                key = " ".join((u.get("name") or "").split()).strip().lower()
                if key and key not in by_lower:
                    by_lower[key] = {"id": u["id"], "name": u["name"]}
            for s in orphaned:
                key = " ".join((s.get("reference") or "").split()).strip().lower()
                hit = by_lower.get(key)
                if hit:
                    await db.students.update_one(
                        {"id": s["id"]},
                        {"$set": {
                            "referrer_user_id": hit["id"],
                            "referrer_name": hit["name"],
                        }},
                    )
    except Exception:
        pass

    # Backfill missing default categories for existing users (idempotent)
    async for u in db.users.find({}, {"id": 1, "_id": 0}):
        existing_cats = await db.categories.find(
            {"user_id": u["id"]}, {"_id": 0, "name": 1, "type": 1}
        ).to_list(1000)
        existing_keys = {(c["name"].lower(), c["type"]) for c in existing_cats}
        missing = [
            {"id": gen_id(), "user_id": u["id"], "created_at": now_iso(), **c}
            for c in DEFAULT_CATEGORIES
            if (c["name"].lower(), c["type"]) not in existing_keys
        ]
        if missing:
            await db.categories.insert_many(missing)
